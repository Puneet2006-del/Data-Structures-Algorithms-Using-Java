package binarysearch;

public class Testing {
    public static void main(String[] args) {
        int[] arr = {2, 2, 6, 7, 0, 1, 2};
        System.out.println(findingPivotRotatedWithDuplicates(arr));
        System.out.println(searchingInRotatedArray(arr,6));
    }

    static int searchingInRotatedArray(int[] arr, int target){
        int pivot = findingPivotRotatedWithDuplicates(arr);
        if(pivot == -1){
            return binarySearch(arr,target,0,arr.length-1);
        } else if (target == pivot) {
            return pivot;
        } else if (arr[0]<target) {
            return binarySearch(arr,target,0,pivot-1);
        }else{
            return binarySearch(arr, target,pivot + 1, arr.length - 1);
        }
    }

    static int binarySearch(int[] arr, int target, int start, int end){
        while (start <= end){
            int mid = start + (end - start) / 2;

            if(target < arr[mid]){
                end = mid - 1;
            } else if (target > arr[mid]) {
                start =  mid + 1;
            }else{
                return mid;
            }
        }
        return - 1;
    }
    
   static int findingPivotRotatedWithDuplicates(int[] arr){
        int start = 0;
        int end = arr.length - 1;
        while(start <= end){
            int mid = start + (end -  start) / 2;
            if(mid < end && arr[mid] > arr[mid + 1]){
                return mid;
            } else if (mid > start && arr[mid] < arr[mid - 1]) {
                return mid - 1;
            }

            if (arr[mid] == arr[start] && arr[mid] == arr[end]){
                if (arr[start] > arr[start + 1]){
                    return start;
                }
                start ++;
                if (arr[end] <  arr[end - 1]){
                    return end - 1;
                }
                end --;
            } else if (arr[start] < arr[mid] || arr[start] == arr[mid] && arr[mid] > arr[end]) {
                start = mid + 1;
            }else{
                end = mid - 1;
            }
        }
        return -1;
   }
}
